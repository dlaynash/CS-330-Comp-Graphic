
#pragma once

#include <GL/glew.h>

#include <glm/glm.hpp>

class Meshes
{
	// Stores GL data relative to given mesh
	struct GLMesh
	{
		GLuint vao;         // Handle for the vertex array object
		GLuint vbos[2];     // Handles for the vertex buffer objects
		GLuint nVertices;	// # vertices for mesh
		GLuint nIndices;    // # indices for mesh
	};

public:
	GLMesh gBoxMesh;
	GLMesh gCylinderMesh;
	GLMesh gPlaneMesh;
	GLMesh gCylinder2Mesh;
	GLMesh gBox2Mesh;
	GLMesh gSphereMesh;
	GLMesh gTorusMesh;

public:
	void CreateMeshes();
	void DestroyMeshes();

private:
	void UCreateBoxMesh(GLMesh& mesh);
	void UCreateCylinderMesh(GLMesh& mesh);
	void UCreatePlaneMesh(GLMesh& mesh);
	void UCreateCylinder2Mesh(GLMesh& mesh);
	void UCreateBox2Mesh(GLMesh& mesh);
	void UCreateTorusMesh(GLMesh& mesh);
	void UCreateSphereMesh(GLMesh& mesh);
	void UDestroyMesh(GLMesh& mesh);
};
